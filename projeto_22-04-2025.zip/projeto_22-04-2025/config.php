<?php
$conn = mysqli_connect('localhost','root','','biblioteca_digital');

$hoje = date('Y-m-d');

$sql = "UPDATE requesitos SET estado = 'atrasado' WHERE fim < ? AND estado != 'atrasado'";
$stmt = $conn->prepare($sql);
if ($stmt) {
    $stmt->bind_param("s", $hoje);
    $stmt->execute();
    $stmt->close();
}

?>