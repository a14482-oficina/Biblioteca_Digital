<?php
session_start();
include('../config.php');
date_default_timezone_set('Europe/Lisbon');

// Verificar se o utilizador está autenticado
if (!isset($_SESSION['utilizador_id'])) {
    header('Location: login.php');
    exit;
}

$id_livro = $_GET['id'] ?? null;
$id_utilizador = $_SESSION['utilizador_id'];

if (!$id_livro) {
    echo "<p style='color:red;'>Livro inválido.</p>";
    exit;
}
?>

<h2>📖 Requesitar Livro</h2>

<!-- Debug visual -->
<p><strong>ID do Livro:</strong> <?= htmlspecialchars($id_livro) ?></p>
<p><strong>ID do Utilizador:</strong> <?= htmlspecialchars($id_utilizador) ?></p>

<form method="post">
    <label>Data de Início:</label>
    <input type="date" name="inicio" required>

    <label>Data de Fim:</label>
    <input type="date" name="fim" required>

    <input type="hidden" name="livro_id" value="<?= htmlspecialchars($id_livro) ?>">
    <button type="submit" name="confirmar_requesito">Requesitar</button>
</form>

<a href="livros.php">Cancelar</a>

<?php
if (isset($_POST['confirmar_requesito'])) {
    $inicio = $_POST['inicio'];
    $fim = $_POST['fim'];
    $livro_id = $_POST['livro_id'];

    echo $inicio;
    echo $fim;

    // Validação de datas

    $hoje = date('Y-m-d');
    if ($inicio < $hoje) {
        echo "<p style='color:red;'>A data de início não pode ser anterior a hoje.</p>";
    } elseif ($inicio > $fim) {
        echo "<p style='color:red;'>Data de fim não pode ser antes da data de início.</p>";
    } else {
        // Inserção segura
        $sql = "INSERT INTO requesitos(id_utilizador, id_livro, inicio, fim) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iiss", $id_utilizador, $livro_id, $inicio, $fim);

        if ($stmt->execute()) {
            echo "<p style='color:green;'>Requisição feita com sucesso!</p>";
            $sql = "UPDATE livros SET stock = stock - 1 WHERE id = ? AND stock > 0";

            $stmt = $conn->prepare($sql);

            if ($stmt === false) {
                echo "<p style='color:red;'>Erro na preparação da consulta: " . $conn->error . "</p>";
                exit;
            }
            $stmt->bind_param("i", $livro_id);

            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    echo "<p style='color:green;'>Livro removido do estoque com sucesso!</p>";
                } else {
                    echo "<p style='color:red;'>Nenhum livro foi removido (pode ser que o estoque esteja vazio).</p>";
                }
            } else {
                echo "<p style='color:red;'>Erro ao remover livro: " . $conn->error . "</p>";
            }
            $stmt->close();
        } else {
            echo "<p style='color:red;'>Erro ao requisitar: " . $conn->error . "</p>";
        }
    }
}
?>
