<?php
session_start();
include('../config.php');
date_default_timezone_set('Europe/Lisbon');


if (isset($_SESSION['utilizador_id'])) {
    $id_utilizador = $_SESSION['utilizador_id'];

    // Consultar todas as informações do utilizador no banco de dados
    $sql_user = "SELECT * FROM utilizador WHERE id = ?";
    $stmt_user = $conn->prepare($sql_user);
    $stmt_user->bind_param("i", $id_utilizador);
    $stmt_user->execute();
    $resultado_user = $stmt_user->get_result();

    if ($resultado_user->num_rows > 0) {
        // Se encontrar o utilizador, armazenar todas as informações
        $user_info = $resultado_user->fetch_assoc();
    } else {
        // Se não encontrar, você pode definir valores padrão ou redirecionar
        echo "<p>Utilizador não encontrado.</p>";
        exit;
    }
} else {
    // Se o utilizador não estiver logado, mostrar um erro ou redirecionar
    echo "<p>Por favor, faça login para acessar esta página.</p>";
    exit;
}

if (isset($_POST['adicionar_livro'])) {
    $nome = $_POST["nome"];
    $autor = $_POST["autor"];
    $lancamento = $_POST["lancamento"];
    $preco = $_POST["preco"];
    $idioma = $_POST["idioma"];
    $categoria = $_POST["categoria"];
    $stock = $_POST["stock"];

    $capa = $_FILES['capa']['name'];
    $capa_tmp_name = $_FILES['capa']['tmp_name'];
    $capa_image_folder = '../uploaded_book_img/'.$capa;

    $sql = "INSERT INTO livros (image, nome, autor, lancamento, preco, idioma, categoria, stock)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssdssi",$capa, $nome, $autor, $lancamento, $preco, $idioma, $categoria, $stock);

    if ($stmt->execute()) {
        move_uploaded_file($capa_tmp_name, $capa_image_folder);
        header("Location: livros.php?mensagem=sucesso");
        exit;
    } else {
        header("Location: livros.php?mensagem=erro");
        exit;
    }
}

// Remoção de livro
if (isset($_POST['remover_livro'])) {
    $id = $_POST['remover_livro'];
    $sql_delete = "DELETE FROM livros WHERE id = ?";
    $stmt_delete = $conn->prepare($sql_delete);
    $stmt_delete->bind_param("i", $id);

    if ($stmt_delete->execute()) {
        echo "<p style='color: green;'>Livro removido com sucesso!</p>";
    } else {
        echo "<p style='color: red;'>Erro ao remover: " . $conn->error . "</p>";
    }
}

$autores = $conn->query("SELECT DISTINCT autor FROM livros");
$categorias = $conn->query("SELECT DISTINCT categoria FROM livros");
$idiomas = $conn->query("SELECT DISTINCT idioma FROM livros");
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Biblioteca Digital</title>
    <!-- Exibe a foto de perfil e o nome do usuário -->
    <div class="perfil">
        <a href="account.php">
        <img src="../uploaded_profile_img/<?= htmlspecialchars($user_info['image']) ?>" alt="Foto de Perfil" height="100">
        </a>
        <p>Bem-vindo, <?= htmlspecialchars($user_info['username']) ?>!</p>
    </div>

    <style>
        .perfil {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 12px;
            padding: 10px 20px;
            background-color: #f8f9fa;
        }

        .perfil p {
            margin: 0;
            font-size: 16px;
            color: #333;
            font-weight: 500;
        }

        .perfil img {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #ddd;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            transition: box-shadow 0.3s ease;
        }

        .perfil img:hover {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
</style>



</head>
<body>
    <h1>📚 Biblioteca Digital</h1>
    <a href="ver_requesitados.php">Ver Calendario</a>

    <h2>Livros Disponíveis</h2>

    <form method="get">
    <input type="text" name="nome" placeholder="Nome do livro...">

        <select name="autor">
            <option value="">Todos os autores</option>
            <?php while ($a = $autores->fetch_assoc()): ?>
                <option value="<?= htmlspecialchars($a['autor']) ?>"><?= htmlspecialchars($a['autor']) ?></option>
            <?php endwhile; ?>
        </select>

        <select name="categoria">
            <option value="">Todas as categorias</option>
            <?php while ($c = $categorias->fetch_assoc()): ?>
                <option value="<?= htmlspecialchars($c['categoria']) ?>"><?= htmlspecialchars($c['categoria']) ?></option>
            <?php endwhile; ?>
        </select>

        <select name="idioma">
            <option value="">Todos os idiomas</option>
            <?php while ($i = $idiomas->fetch_assoc()): ?>
                <option value="<?= htmlspecialchars($i['idioma']) ?>"><?= htmlspecialchars($i['idioma']) ?></option>
            <?php endwhile; ?>
        </select>

        <button type="submit">🔍 Pesquisar</button>
    </form>

    <?php
    if (!empty($_GET['nome']) || !empty($_GET['autor']) || !empty($_GET['categoria']) || !empty($_GET['idioma'])) {
        include 'pesquisa.php';
    }else{
        $sql = "SELECT * FROM livros";
        $resultado = $conn->query($sql);

        if ($resultado->num_rows > 0) {
        echo "<table border='1'>";
        echo "<tr>
                <th>ID</th>
                <th>Image</th>
                <th>Nome</th>
                <th>Autor</th>
                <th>Lançamento</th>
                <th>Preço (€)</th>
                <th>Idioma</th>
                <th>Categoria</th>
                <th>Stock</th>
                <th>Requesitar</th>
              </tr>";
        while ($linha = $resultado->fetch_assoc()) {
            echo "<tr>
                    <td>{$linha['id']}</td>
                    <td><img src='../uploaded_book_img/{$linha['image']}' height='100' alt=''></td>
                    <td>{$linha['nome']}</td>
                    <td>{$linha['autor']}</td>
                    <td>{$linha['lancamento']}</td>
                    <td>{$linha['preco']}€</td>
                    <td>{$linha['idioma']}</td>
                    <td>{$linha['categoria']}</td>
                    <td>{$linha['stock']}</td>
                    <td>
                        <form action='requesitar.php' method='get' style='display:inline;'>
                            <input type='hidden' name='id' value='{$linha['id']}'>
                            <button type='submit'>✏️</button>
                        </form>
                    </td>
                  </tr>";
        }
        echo "</table>";
        } else {
            echo "<p>Nenhum livro encontrado.</p>";
        }
    }

    $conn->close();
    ?>

    <div class="logout">
        <a href="../logout.php">🔒 Logout</a>
    </div>

</body>
</html>
