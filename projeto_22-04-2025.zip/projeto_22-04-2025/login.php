<?php
session_start();
include('config.php');
date_default_timezone_set('Europe/Lisbon');

$erro_msg = "";

// Exibir alerta se a conta estiver inativa
if (isset($_GET['erro']) && $_GET['erro'] == 'inativo') {
    echo "<script>alert('A sua conta está inativa. Contacte o Admin.');</script>";
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $login = $_POST['login']; // username ou email
    $password = $_POST['password'];

    $sql = "SELECT * FROM utilizador WHERE email = ? OR username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $login, $login);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {
            // Login bem-sucedido
            $_SESSION['utilizador_id'] = $user['id'];
            $estado = (int)$user['estado']; // Aqui você pega o estado do usuário

            // Verifique o estado
            if ($estado == 1) {
                header("Location: admin_pages/livros.php");  // Se o estado for 1, redireciona para a página de admin
                exit();
            } elseif ($estado == 0) {
                header("Location: client_pages/livros.php"); // Se o estado for 0, redireciona para a página do cliente
                exit();
            } else {
                $erro_msg = "❌ Estado de utilizador desconhecido.";
            }
        } else {
            $erro_msg = "❌ Palavra-passe incorreta.";
        }
    } else {
        $erro_msg = "❌ Email ou nome de utilizador não encontrado.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-pt">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #e0e0e0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .login-container {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
        }

        .login-container h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .login-container form {
            display: flex;
            flex-direction: column;
        }

        .login-container input {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }

        .login-container input[type="submit"] {
            background-color: #2196F3;
            color: white;
            font-weight: bold;
            cursor: pointer;
            border: none;
            transition: background 0.3s;
        }

        .login-container input[type="submit"]:hover {
            background-color: #1976D2;
        }

        .erro {
            color: red;
            margin-bottom: 10px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>

        <?php if (!empty($erro_msg)) echo "<div class='erro'>$erro_msg</div>"; ?>

        <form method="POST" action="">
            <input type="text" name="login" placeholder="Email ou nome de utilizador" required>
            <input type="password" name="password" placeholder="Palavra-passe" required>
            <input type="submit" value="Entrar">
        </form>
        <a href="registo.php">Se não tiver conta, clique aqui</a>
    </div>
</body>
</
