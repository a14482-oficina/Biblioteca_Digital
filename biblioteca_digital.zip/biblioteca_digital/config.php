<?php
session_set_cookie_params(0); // 0 = até fechar navegador
session_start();

$conn = mysqli_connect('','','','');
$hoje = date('Y-m-d');

$sql = "UPDATE requesitos SET estado = 'atrasado' WHERE fim < ? AND estado != 'atrasado' AND estado != 'aceite'";
$stmt = $conn->prepare($sql);
if ($stmt) {
    $stmt->bind_param("s", $hoje);
    $stmt->execute();
    $stmt->close();
}

?>