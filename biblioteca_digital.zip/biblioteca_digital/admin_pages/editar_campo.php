<?php
include('../config.php');
date_default_timezone_set('Europe/Lisbon');

if (!isset($_SESSION['utilizador_id'])) {
    header("Location: login.php");
    exit;
}

$id = $_SESSION['utilizador_id'];

// Adiciona "image" aos campos permitidos
$campo_permitido = ['nome', 'username', 'email', 'telefone', 'image'];
$campo = isset($_GET['campo']) ? $_GET['campo'] : '';

if (!in_array($campo, $campo_permitido)) {
    echo "Campo inválido.";
    exit;
}

// Obter valor atual
$sql = "SELECT $campo FROM utilizador WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$valor_atual = $user[$campo];

// Atualização
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($campo === 'image') {
        if (isset($_FILES['novo_valor']) && $_FILES['novo_valor']['error'] === 0) {
            $imagem = $_FILES['novo_valor'];
            $extensao = pathinfo($imagem['name'], PATHINFO_EXTENSION);
            $novo_nome = uniqid("perfil_", true) . '.' . $extensao; //uniqid cria um id novo apartir da hora, perfil_idunico
            $caminho = '../uploaded_profile_img/' . $novo_nome;

            if (move_uploaded_file($imagem['tmp_name'], $caminho)) {
                $sql_update = "UPDATE utilizador SET image = ? WHERE id = ?";
                $stmt_update = $conn->prepare($sql_update);
                $stmt_update->bind_param("si", $novo_nome, $id);
                $stmt_update->execute();

                $_SESSION['utilizador_image'] = $novo_nome;
                header("Location: account.php");
                exit;
            } else {
                $erro = "Erro ao guardar a imagem.";
            }
        } else {
            $erro = "Erro ao carregar imagem.";
        }
    } else {
        $novo_valor = $_POST['novo_valor'];
        $sql_update = "UPDATE utilizador SET $campo = ? WHERE id = ?";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->bind_param("si", $novo_valor, $id);

        if ($stmt_update->execute()) {
            header("Location: account.php");
            exit;
        } else {
            $erro = "Erro ao atualizar: " . $conn->error;
        }
    }
}
?>

<h2>Editar <?= ucfirst($campo) ?></h2>

<?php if (isset($erro)) echo "<p style='color:red;'>$erro</p>"; ?>

<?php if ($campo === 'image'): ?>
    <form method="post" enctype="multipart/form-data">
        <input type="file" name="novo_valor" accept="image/*" required>
        <button type="submit">Guardar</button>
    </form>
<?php else: ?>
    <form method="post">
        <input type="text" name="novo_valor" value="<?= htmlspecialchars($valor_atual) ?>" required>
        <button type="submit">Guardar</button>
    </form>
<?php endif; ?>

<a href="account.php">Cancelar</a>
