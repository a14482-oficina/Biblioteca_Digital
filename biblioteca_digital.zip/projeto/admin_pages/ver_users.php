<?php
include('../config.php');
date_default_timezone_set('Europe/Lisbon');

$sql = "SELECT * FROM utilizador";
$resultado = $conn->query($sql);

if (isset($_POST['remover_user'])) {
    $id = $_POST['remover_user'];
    $sql_delete = "DELETE FROM utilizador WHERE id = ?";
    $stmt_delete = $conn->prepare($sql_delete);
    $stmt_delete->bind_param("i", $id);

    if ($stmt_delete->execute()) {
        echo "<p style='color: green;'>User removido com sucesso!</p>";
    } else {
        echo "<p style='color: red;'>Erro ao remover: " . $conn->error . "</p>";
    }
}

if ($resultado->num_rows > 0) {
    echo "<table border='1'>";
    echo "<tr>
            <th>ID</th>
            <th>Nome</th>
            <th>telefone</th>
            <th>username</th>
            <th>email</th>
            <th>estado</th>
            </tr>";
    while ($linha = $resultado->fetch_assoc()) {
        $estado = $linha['estado'] == 1 ? 'admin' : 'utilizador';
        echo "<tr>
                <td>{$linha['id']}</td>
                <td>{$linha['nome']}</td>
                <td>{$linha['telefone']}</td>
                <td>{$linha['username']}</td>
                <td>{$linha['email']}</td>
                <td>{$estado}</td>
                <td>
                    <form action='ver_requesitados.php' method='get' style='display:inline;'>
                        <input type='hidden' name='user_id' value='" . $linha['id'] . "'>
                        <button type='submit' class='ver-intervalo' title='Ver calendário deste utilizador'>📅</button>
                    </form>

                </td>
                <td>
                    <form action='editar_user.php' method='get' style='display:inline;'>
                        <input type='hidden' name='id' value='{$linha['id']}'>
                        <button type='submit'>✏️</button>
                    </form>
                </td>
                <td>
                    <form method='post' style='display:inline;'>
                        <input type='hidden' name='remover_user' value='{$linha['id']}'>
                        <button type='submit' onclick=\"return confirm('Tem a certeza que quer remover este livro?');\">🗑️</button>
                    </form>
                </td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "<p>Nenhum livro encontrado.</p>";
}
?>

<a href="livros.php">Pagina principal</a>
