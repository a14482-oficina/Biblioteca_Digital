<?php
session_start();
include('../config.php');
date_default_timezone_set('Europe/Lisbon');

$nome = isset($_GET['nome']) ? $conn->real_escape_string($_GET['nome']) : '';
$autor = isset($_GET['autor']) ? $conn->real_escape_string($_GET['autor']) : '';
$categoria = isset($_GET['categoria']) ? $conn->real_escape_string($_GET['categoria']) : '';
$idioma = isset($_GET['idioma']) ? $conn->real_escape_string($_GET['idioma']) : '';

$sql = "SELECT * FROM livros WHERE 1"; // base neutra

if (!empty($nome)) {
    $sql .= " AND nome LIKE '%$nome%'";
}
if (!empty($autor)) {
    $sql .= " AND autor = '$autor'";
}
if (!empty($categoria)) {
    $sql .= " AND categoria = '$categoria'";
}
if (!empty($idioma)) {
    $sql .= " AND idioma = '$idioma'";
}

$resultado = $conn->query($sql);

if ($resultado->num_rows > 0) {
    echo "<table border='1'>
            <tr>
                <th>ID</th>
                <th>Imagem</th>
                <th>Nome</th>
                <th>Autor</th>
                <th>Lançamento</th>
                <th>Preço (€)</th>
                <th>Idioma</th>
                <th>Categoria</th>
                <th>Stock</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>";

    while ($linha = $resultado->fetch_assoc()) {
        echo "<tr>
                <td>{$linha['id']}</td>
                <td><img src='uploaded_book_img/{$linha['image']}' height='80'></td>
                <td>{$linha['nome']}</td>
                <td>{$linha['autor']}</td>
                <td>{$linha['lancamento']}</td>
                <td>{$linha['preco']}€</td>
                <td>{$linha['idioma']}</td>
                <td>{$linha['categoria']}</td>
                <td>{$linha['stock']}</td>
                <td>
                    <form action='editar_livros.php' method='get' style='display:inline;'>
                        <input type='hidden' name='id' value='{$linha['id']}'>
                        <button type='submit'>✏️</button>
                    </form>
                </td>
                <td>
                    <form method='post' style='display:inline;'>
                        <input type='hidden' name='remover_livro' value='{$linha['id']}'>
                        <button type='submit' onclick=\"return confirm('Tem a certeza que quer remover este livro?');\">🗑️</button>
                    </form>
                </td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "<p>Nenhum resultado encontrado.</p>";
}
?>