<?php
session_start();
include('../config.php');
date_default_timezone_set('Europe/Lisbon');

// Verifica se o utilizador está autenticado
if (!isset($_SESSION['utilizador_id'])) {
    header("Location: login.php"); // ou mostra uma mensagem
    exit;
}

$id = $_SESSION['utilizador_id'];

// Vai buscar os dados do utilizador à base de dados
$sql = "SELECT * FROM utilizador WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$resultado = $stmt->get_result();

if ($resultado->num_rows === 0) {
    echo "Utilizador não encontrado.";
    exit;
}

$user = $resultado->fetch_assoc();
?>

<h2>Minha Conta</h2>

<p>
    <img src="../uploaded_profile_img/<?= htmlspecialchars($_SESSION['utilizador_image']) ?>" alt="Foto de Perfil" height="100">
    <a href="editar_campo.php?campo=image&id=<?= $user['id'] ?>"><button>Editar</button></a>
</p>

<p>
    <strong>Nome:</strong> <?= htmlspecialchars($user['nome']) ?>
    <a href="editar_campo.php?campo=nome&id=<?= $user['id'] ?>"><button>Editar</button></a>
</p>

<p>
    <strong>Username:</strong> <?= htmlspecialchars($user['username']) ?>
    <a href="editar_campo.php?campo=username&id=<?= $user['id'] ?>""><button>Editar</button></a>
</p>

<p>
    <strong>Email:</strong> <?= htmlspecialchars($user['email']) ?>
    <a href="editar_campo.php?campo=email&id=<?= $user['id'] ?>""><button>Editar</button></a>
</p>

<p>
    <strong>Telefone:</strong> <?= htmlspecialchars($user['telefone']) ?>
    <a href="editar_campo.php?campo=telefone&id=<?= $user['id'] ?>""><button>Editar</button></a>
</p>

<a href="livros.php">Pagina Principal</a>