<?php
include('../config.php');
date_default_timezone_set('Europe/Lisbon');

if (!isset($_GET['id'])) {
    echo "ID não fornecido.";
    exit;
}

$id = (int) $_GET['id'];
$sql = "SELECT * FROM livros WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$resultado = $stmt->get_result();

if ($resultado->num_rows === 0) {
    echo "Utilizador não encontrado.";
    exit;
}

$user = $resultado->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $autor = $_POST['autor'];
    $lancamento = $_POST['lancamento'];
    $preco = $_POST['preco'];
    $idioma = $_POST['idioma'];
    $categoria = $_POST['categoria'];
    $stock = $_POST['stock'];

    // Verifica se o utilizador enviou nova imagem
    $novaImagem = $_FILES['nova_capa']['name'];
    $novaImagemTmp = $_FILES['nova_capa']['tmp_name'];

    if (!empty($novaImagem)) {
        $extensao = pathinfo($novaImagem, PATHINFO_EXTENSION);
        $nomeUnico = uniqid("livro_", true) . '.' . $extensao;
        $caminhoImagem = '../uploaded_book_img/' . $nomeUnico;

        // Move a nova imagem
        move_uploaded_file($novaImagemTmp, $caminhoImagem);

        // Atualiza com imagem
        $sql_update = "UPDATE livros SET image=?, nome=?, autor=?, lancamento=?, preco=?, idioma=?, categoria=?, stock=? WHERE id=?";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->bind_param("ssssissii", $nomeUnico, $nome, $autor, $lancamento, $preco, $idioma, $categoria, $stock, $id);
    } else {
        // Atualiza sem imagem
        $sql_update = "UPDATE livros SET nome=?, autor=?, lancamento=?, preco=?, idioma=?, categoria=?, stock=? WHERE id=?";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->bind_param("sssissii", $nome, $autor, $lancamento, $preco, $idioma, $categoria, $stock, $id);
    }

    if ($stmt_update->execute()) {
        header("Location: livros.php");
        exit;
    } else {
        echo "<p style='color: red;'>Erro ao atualizar: " . $conn->error . "</p>";
    }
}

?>

<h2>Editar Livro</h2>
<form method="post" enctype="multipart/form-data">

    <p>Imagem atual:</p>
    <img src="../uploaded_book_img/<?= htmlspecialchars($user['image']) ?>" height="120" alt="Capa atual"><br>


    <label>Nova Capa:</label><br>
    <input type="file" name="nova_capa" accept="image/png, image/jpeg, image/jpg"><br>

    <label>Nome:</label><br>
    <input type="text" name="nome" value="<?= htmlspecialchars($user['nome']) ?>"><br>

    <label>Autor:</label><br>
    <input type="text" name="autor" value="<?= htmlspecialchars($user['autor']) ?>"><br>

    <label>lancamento:</label><br>
    <input type="text" name="lancamento" value="<?= htmlspecialchars($user['lancamento']) ?>"><br>

    <label>Preço:</label><br>
    <input type="number" name="preco" value="<?= htmlspecialchars($user['preco']) ?>"><br>

    <label>Idioma:</label><br>
    <input type="text" name="idioma" value="<?= htmlspecialchars($user['idioma']) ?>"><br>

    <label>categoria:</label><br>
    <input type="text" name="categoria" value="<?= htmlspecialchars($user['categoria']) ?>"><br>

    <label>stock:</label><br>
    <input type="number" name="stock" value="<?= htmlspecialchars($user['stock']) ?>"><br>

    <button type="submit">Guardar</button>
</form>