<?php
session_start();
include('../config.php');
date_default_timezone_set('Europe/Lisbon');

if (!isset($_GET['id'])) {
    echo "ID não fornecido.";
    exit;
}

$id = (int) $_GET['id'];
$sql = "SELECT * FROM utilizador WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$resultado = $stmt->get_result();

if ($resultado->num_rows === 0) {
    echo "Utilizador não encontrado.";
    exit;
}

$user = $resultado->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $telefone = $_POST['telefone'];
    $estado = $_POST['estado'];

    // Verifica se foi enviada uma nova imagem
    if (!empty($_FILES['imagem']['name'])) {
        $imagem = $_FILES['imagem'];
        $extensao = pathinfo($imagem['name'], PATHINFO_EXTENSION);
        $nome_imagem = uniqid('perfil_', true) . '.' . $extensao;
        $destino = '../uploaded_profile_img/' . $nome_imagem;

        // Verifica se a extensão é válida
        $ext_permitidas = ['jpg', 'jpeg', 'png', 'gif'];
        if (!in_array(strtolower($extensao), $ext_permitidas)) {
            echo "<p style='color:red;'>Formato de imagem não suportado!</p>";
            exit;
        }

        move_uploaded_file($imagem['tmp_name'], $destino);

        // Atualiza com imagem
        $sql_update = "UPDATE utilizador SET nome=?, email=?, username=?, telefone=?, estado=?, image=? WHERE id=?";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->bind_param("ssssssi", $nome, $email, $username, $telefone, $estado, $nome_imagem, $id);
    } else {
        // Atualiza sem imagem
        $sql_update = "UPDATE utilizador SET nome=?, email=?, username=?, telefone=?, estado=? WHERE id=?";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->bind_param("ssssii", $nome, $email, $username, $telefone, $estado, $id);
    }

    if ($stmt_update->execute()) {
        header("Location: ver_users.php?mensagem=atualizado");
        exit;
    } else {
        echo "<p style='color: red;'>Erro ao atualizar: " . $conn->error . "</p>";
    }
}
?>

<h2>Editar Utilizador</h2>
<form method="post" enctype="multipart/form-data">

    <label>Imagem de Perfil:</label><br>
    <input type="file" name="imagem" accept=".jpg,.jpeg,.png,.gif"><br>
    <?php if (!empty($user['image'])): ?>
        <img src="../uploaded_profile_img/<?= htmlspecialchars($user['image']) ?>" height="100"><br>
    <?php endif; ?>

    <label>Nome:</label><br>
    <input type="text" name="nome" value="<?= htmlspecialchars($user['nome']) ?>"><br>

    <label>Email:</label><br>
    <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>"><br>

    <label>Username:</label><br>
    <input type="text" name="username" value="<?= htmlspecialchars($user['username']) ?>"><br>

    <label>Telefone:</label><br>
    <input type="text" name="telefone" value="<?= htmlspecialchars($user['telefone']) ?>"><br>

    <label>Estado:</label><br>
    <input type="number" name="estado" min = '0' max = '1' value="<?= htmlspecialchars($user['estado']) ?>"><br>

    <button type="submit">Guardar</button>
</form>