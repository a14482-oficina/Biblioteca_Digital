<?php
$conn = mysqli_connect('sql204.alojamento-gratis.com','ljmn_38553710','Fredvspvp123456','ljmn_38553710_biblioteca_digital');

$hoje = date('Y-m-d');

$sql = "UPDATE requesitos SET estado = 'atrasado' WHERE fim < ? AND estado != 'atrasado'";
$stmt = $conn->prepare($sql);
if ($stmt) {
    $stmt->bind_param("s", $hoje);
    $stmt->execute();
    $stmt->close();
}

?>