<?php
session_start();
@include 'config.php';
date_default_timezone_set('Europe/Lisbon');

$erro_msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['registar_utilizador'])) {
    $nome = $_POST['nome'];
    $telefone = $_POST['telefone'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirmar_palavra_passe = $_POST['confirmar_palavra_passe'];

    // Verifica se uma imagem foi enviada
    if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] === UPLOAD_ERR_OK) {
        $imagem_nome = $_FILES['imagem']['name'];
        $imagem_tmp = $_FILES['imagem']['tmp_name'];
        $imagem_folder = '../uploaded_profile_img/' . $imagem_nome;
        
        // Verifica a extensão do arquivo
        $extensao = pathinfo($imagem_nome, PATHINFO_EXTENSION);
        $extensoes_permitidas = ['jpg', 'jpeg', 'png'];

        if (!in_array(strtolower($extensao), $extensoes_permitidas)) {
            $erro_msg = "❌ O arquivo não é uma imagem válida.";
        }
    } else {
        // Caso nenhuma imagem seja enviada, define uma padrão
        $extensao = pathinfo($imagem_nome, PATHINFO_EXTENSION);
        $imagem_nome = uniqid("perfil_", true) . '.' . $extensao;
        $imagem_folder = '../uploaded_profile_img/' . $imagem_nome;
        $imagem_folder = '../uploaded_profile_img/' . $imagem_nome;
    }

    if ($confirmar_palavra_passe !== $password) {
        $erro_msg = "❌ As palavras-passe não coincidem.";
    } else {
        // Verifica se o e-mail ou username já estão registados
        $sql_check = "SELECT * FROM utilizador WHERE email = ? OR username = ?";
        $stmt_check = $conn->prepare($sql_check);
        $stmt_check->bind_param("ss", $email, $username);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();

        if ($result_check->num_rows > 0) {
            $erro_msg = "❌ O e-mail ou nome de utilizador já está em uso.";
        } else {
            $estado = 0;
            $password_hashed = password_hash($password, PASSWORD_DEFAULT);

            $sql = "INSERT INTO utilizador (image, nome, telefone, username, email, password, estado)
                    VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssssi", $imagem_nome, $nome, $telefone, $username, $email, $password_hashed, $estado);

            if ($stmt->execute()) {
                // Move a imagem apenas se for enviada pelo utilizador
                if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] === UPLOAD_ERR_OK) {
                    move_uploaded_file($imagem_tmp, $imagem_folder);
                }
                header("Location: login.php");
                exit();
            } else {
                $erro_msg = "❌ Erro ao registar: " . $stmt->error;
            }
        }
    }
}
?>


<!DOCTYPE html>
<html lang="pt-pt">
<head>
    <meta charset="UTF-8">
    <title>Registro de Conta</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .registro-container {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
        }

        .registro-container h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .registro-container form {
            display: flex;
            flex-direction: column;
        }

        .registro-container input {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }

        .registro-container input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            font-weight: bold;
            cursor: pointer;
            border: none;
            transition: background 0.3s;
        }

        .registro-container input[type="submit"]:hover {
            background-color: #45a049;
        }

        .erro {
            color: red;
            margin-bottom: 10px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="registro-container">
        <h2>Criar Conta</h2>

        <?php if (!empty($erro_msg)) echo "<div class='erro'>$erro_msg</div>"; ?>

        <form method="POST" action="" enctype="multipart/form-data">
            <input type="text" name="nome" placeholder="Nome completo" required>
            <input type="text" name="telefone" placeholder="Telefone" required>
            <input type="text" name="username" placeholder="Nome de utilizador" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Palavra-passe" required>
            <input type="password" name="confirmar_palavra_passe" placeholder="Confirmar palavra-passe" required>
            <input type="file" name="imagem" accept="image/png, image/jpeg, image/jpg" placeholder="Escolha uma imagem (opcional)">
            <input type="submit" name="registar_utilizador" value="Criar Conta">
        </form>

        <a href="login.php">Já tem conta, login</a>
    </div>
</body>
</html>

