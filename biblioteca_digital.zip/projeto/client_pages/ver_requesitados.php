<?php
include('../config.php');
date_default_timezone_set('Europe/Lisbon');

// Verifica se o usuário está logado
if (!isset($_SESSION['utilizador_id'])) {
    echo "<p style='color:red;'>Por favor, faça login para acessar sua página.</p>";
    exit;
}

// Recupera o ID do usuário logado
$user_id = $_SESSION['utilizador_id'];

// Buscar todos os intervalos de requisição da base de dados para o usuário logado
$sql = "SELECT r.inicio, r.fim, l.nome 
        FROM requesitos r 
        JOIN livros l ON r.id_livro = l.id 
        WHERE r.id_utilizador = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);  // Binding do user_id para a consulta
$stmt->execute();
$result = $stmt->get_result();

$datasRequisicoes = [];

while ($row = $result->fetch_assoc()) {
    $datasRequisicoes[] = $row;
}

echo "<script>var datasRequisicoes = " . json_encode($datasRequisicoes) . ";</script>";
?>

<style>
/* Estilo do calendário */
.calendario-dinamico {
            margin-top: 40px;
            background: #f8f9fa;
            padding: 20px;
            max-width: 600px;
            border-radius: 10px;
            margin-left: auto;
            margin-right: auto;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .header h2 {
            margin: 0;
        }

        .calendar-grid {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 8px;
            text-align: center;
        }

        .calendar-grid div {
            padding: 10px;
            border-radius: 5px;
        }

        .day-name {
            font-weight: bold;
            color: #495057;
            background: #e9ecef;
        }

        .day-number {
            background: #dee2e6;
            transition: background 0.2s;
        }

        .day-number:hover {
            background: #adb5bd;
            color: white;
            cursor: pointer;
        }

        .empty {
            background: transparent;
        }
        .day-number.highlight {
        background-color: #ff9900;
        color: white;
        border-radius: 5px;
        font-weight: bold;
        position: relative;
        cursor: pointer;
        transition: transform 0.2s ease;
        }

        .day-number.highlight:hover {
            transform: scale(1.15);
            background-color: #ff6600;
        }

        .day-number[data-tooltip]:hover::after {
            content: attr(data-tooltip);
            position: absolute;
            bottom: 110%;
            left: 50%;
            transform: translateX(-50%);
            background-color: #333;
            color: #fff;
            padding: 4px 8px;
            border-radius: 6px;
            white-space: nowrap;
            font-size: 12px;
            z-index: 999;
            opacity: 0.95;
        }
</style>

<a href="livros.php">Página Inicial</a>

<?php
// Buscar as requisições do usuário logado
$sql_tabela = "SELECT * FROM requesitos WHERE id_utilizador = ?";
$stmt_tabela = $conn->prepare($sql_tabela);
$stmt_tabela->bind_param("i", $user_id);
$stmt_tabela->execute();
$resultado_tabela = $stmt_tabela->get_result();

if ($resultado_tabela->num_rows > 0) {
    echo "<table border='1'>";
    echo "<tr>
            <th>ID</th>
            <th>id_livro</th>
            <th>Inicio</th>
            <th>Fim</th>
            <th>Estado</th>
          </tr>";
    while ($linha = $resultado_tabela->fetch_assoc()) {
        echo "<tr>
                <td>{$linha['id']}</td>
                <td>{$linha['id_livro']}</td>
                <td>{$linha['inicio']}</td>
                <td>{$linha['fim']}</td>
                <td>{$linha['estado']}</td>
                <td><button class='ver-intervalo' 
                    data-inicio='{$linha['inicio']}' 
                    data-fim='{$linha['fim']}'>📅 Ver no calendário</button></td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "<p>Nenhuma requisição encontrada.</p>";
}
?>

<div class="calendario-dinamico">
    <div class="header">
        <button id="prev">◀</button>
        <h2 id="mesAno"></h2>
        <button id="next">▶</button>
    </div>
    <div class="calendar-grid" id="calendar">
        <!-- Dias e datas serão gerados com JS -->
    </div>
</div>

<script>
    const calendar = document.getElementById("calendar");
    const mesAno = document.getElementById("mesAno");
    const meses = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", 
                    "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];

    let hoje = new Date();
    let mesAtual = hoje.getMonth();
    let anoAtual = hoje.getFullYear();

    // Função para converter string de data para objeto Date
    function parseDate(dateString) {
        const parts = dateString.split("-");
        return new Date(parts[0], parts[1] - 1, parts[2]);
    }

    function gerarCalendario(mes, ano) {
        calendar.innerHTML = "";

        const diasSemana = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
        diasSemana.forEach(d => {
            const div = document.createElement("div");
            div.textContent = d;
            div.className = "day-name";
            calendar.appendChild(div);
        });

        const primeiroDia = new Date(ano, mes, 1).getDay();
        const diasNoMes = new Date(ano, mes + 1, 0).getDate();

        for (let i = 0; i < primeiroDia; i++) {
            const empty = document.createElement("div");
            empty.className = "empty";
            calendar.appendChild(empty);
        }

        for (let i = 1; i <= diasNoMes; i++) {
            const dia = document.createElement("div");
            dia.textContent = i;
            dia.className = "day-number";

            const dataAtual = new Date(ano, mes, i);
            dataAtual.setHours(0, 0, 0, 0);
            let livrosDoDia = [];

            if (Array.isArray(datasRequisicoes)) {
                datasRequisicoes.forEach(({ inicio, fim, nome }) => {
                    const dataInicio = new Date(inicio);
                    const dataFim = new Date(fim);
                    dataInicio.setHours(0, 0, 0, 0);
                    dataFim.setHours(0, 0, 0, 0);

                    // Verifica se o dia atual está dentro do intervalo de requisição
                    if (dataAtual >= dataInicio && dataAtual <= dataFim) {
                        livrosDoDia.push({ nome, inicio, fim });

                        // Para destacar todos os dias dentro do intervalo
                        let dataDentroIntervalo = new Date(dataInicio);
                        while (dataDentroIntervalo <= dataFim) {
                            const diaDentroIntervalo = new Date(dataDentroIntervalo);
                            // Verifica se o dia atual do calendário é igual a um dia dentro do intervalo
                            if (diaDentroIntervalo.getDate() === dataAtual.getDate() &&
                                diaDentroIntervalo.getMonth() === dataAtual.getMonth() &&
                                diaDentroIntervalo.getFullYear() === dataAtual.getFullYear()) {
                                dia.classList.add("highlight");
                            }
                            // Avança para o próximo dia
                            dataDentroIntervalo.setDate(dataDentroIntervalo.getDate() + 1);
                        }
                    }
                });
            }

            if (livrosDoDia.length > 0) {
                // Monta o conteúdo da tooltip com título e período
                const tooltipContent = livrosDoDia.map(({ nome, inicio, fim }) => {
                    return `${nome} (${inicio} a ${fim})`;
                }).join("<br>"); // "<br>" para separar os livros com uma quebra de linha

                dia.setAttribute("data-tooltip", tooltipContent);
            }

            calendar.appendChild(dia);
        }

        mesAno.textContent = `${meses[mes]} ${ano}`;
    }

    document.getElementById("prev").addEventListener("click", () => {
        mesAtual--;
        if (mesAtual < 0) {
            mesAtual = 11;
            anoAtual--;
        }
        gerarCalendario(mesAtual, anoAtual);
    });

    document.getElementById("next").addEventListener("click", () => {
        mesAtual++;
        if (mesAtual > 11) {
            mesAtual = 0;
            anoAtual++;
        }
        gerarCalendario(mesAtual, anoAtual);
    });

    gerarCalendario(mesAtual, anoAtual);

// Manipular os botões "Ver no calendário"
document.querySelectorAll('.ver-intervalo').forEach(botao => {
    botao.addEventListener('click', () => {
        const inicio = new Date(botao.dataset.inicio);
        const fim = new Date(botao.dataset.fim);

        // Limpa os destaques anteriores
        document.querySelectorAll('.day-number').forEach(d => {
            d.classList.remove('highlight');
            d.removeAttribute('data-tooltip');
        });

        // Atualiza mês e ano se necessário
        mesAtual = inicio.getMonth();
        anoAtual = inicio.getFullYear();
        gerarCalendario(mesAtual, anoAtual);

        // Destacar os dias do intervalo
        let dataAtual = new Date(inicio);
        while (dataAtual <= fim) {
            const dia = dataAtual.getDate();
            const mes = dataAtual.getMonth();
            const ano = dataAtual.getFullYear();

            // Regerar calendário novamente para garantir que o mês está correto
            if (mes === mesAtual && ano === anoAtual) {
                // Aguardar 50ms para garantir que o DOM foi atualizado
                setTimeout(() => {
                    document.querySelectorAll('.day-number').forEach(el => {
                        if (parseInt(el.textContent) === dia) {
                            el.classList.add('highlight');
                            el.setAttribute('data-tooltip', `${nome} (${inicio} a ${fim})`);
                        }
                    });
                }, 50);
            }

            dataAtual.setDate(dataAtual.getDate() + 1);
        }

        // Scrollar suavemente até o calendário
        document.querySelector('.calendario-dinamico').scrollIntoView({ behavior: 'smooth' });
    });
});
    
</script>
